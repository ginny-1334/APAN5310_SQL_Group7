-- Scheduled Labor Hours — Testable version
WITH params AS (
  SELECT
    DATE '2023-07-01' AS start_date,
    DATE '2023-07-31' AS end_date,
    NULL::int        AS store_id   -- set to a store_id (e.g., 1) to filter, or keep NULL for all
),
base AS (
  SELECT
      ss.shift_date,
      e.store_id,
      ss.employee_id,
      -- hours per shift, handling overnight (end < start)
      GREATEST(
        EXTRACT(EPOCH FROM (
          CASE
            WHEN ss.end_time >= ss.start_time
              THEN ss.end_time - ss.start_time
            ELSE ss.end_time - ss.start_time + INTERVAL '24 hours'
          END
        )) / 3600.0,
        0
      ) AS hours
  FROM ShiftSchedule ss
  JOIN Employee e ON e.employee_id = ss.employee_id
  WHERE ss.shift_date BETWEEN (SELECT start_date FROM params) AND (SELECT end_date FROM params)
    AND (
      (SELECT store_id FROM params) IS NULL
      OR e.store_id = (SELECT store_id FROM params)
    )
)
SELECT
  b.store_id,
  b.shift_date,
  ROUND(SUM(b.hours)::numeric, 2) AS scheduled_hours,
  COUNT(DISTINCT b.employee_id)   AS scheduled_headcount
FROM base b
GROUP BY b.store_id, b.shift_date
ORDER BY b.shift_date, b.store_id;

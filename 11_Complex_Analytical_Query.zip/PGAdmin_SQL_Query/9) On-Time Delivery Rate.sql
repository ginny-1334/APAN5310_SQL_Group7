-- On-time Delivery Rate (by Vendor, optional Store) 
-- Adjust dates and (optionally) uncomment the store filter.

WITH deliveries AS (
  SELECT
    d.vendor_id,
    d.store_id,
    d.status
  FROM Delivery d
  WHERE d.delivery_date BETWEEN DATE '2024-01-01' AND DATE '2024-01-31'  -- ← change me
    -- AND d.store_id = 1  -- ← optional filter
),
agg AS (
  SELECT
    d.vendor_id,
    d.store_id,
    COUNT(*)::numeric AS total_deliveries,
    SUM(CASE WHEN d.status = 'Delayed' THEN 1 ELSE 0 END)::numeric AS delayed_deliveries
  FROM deliveries d
  GROUP BY d.vendor_id, d.store_id
)
SELECT
  a.vendor_id,
  v.vendor_name,
  a.store_id,
  a.total_deliveries,
  a.delayed_deliveries,
  ROUND(
    CASE WHEN a.total_deliveries > 0
         THEN 1 - (a.delayed_deliveries / a.total_deliveries)
         ELSE NULL
    END, 4
  ) AS on_time_rate
FROM agg a
LEFT JOIN Vendor v ON v.vendor_id = a.vendor_id
ORDER BY on_time_rate DESC NULLS LAST, total_deliveries DESC, v.vendor_name;

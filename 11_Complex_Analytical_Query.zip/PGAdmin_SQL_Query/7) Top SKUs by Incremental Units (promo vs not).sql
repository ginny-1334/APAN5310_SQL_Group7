-- Top SKUs Incremental Units (promo vs not)

WITH promo_units AS (
    SELECT 
        si.sku,
        SUM(si.quantity_sold) AS total_promo_units
    FROM SaleItem si
    JOIN Promotion p ON si.promo_id = p.promo_id
    GROUP BY si.sku
),
non_promo_units AS (
    SELECT 
        si.sku,
        SUM(si.quantity_sold) AS total_non_promo_units
    FROM SaleItem si
    WHERE si.promo_id IS NULL
    GROUP BY si.sku
)
SELECT 
    pu.sku,
    pr.product_name,
    COALESCE(pu.total_promo_units, 0) - COALESCE(np.total_non_promo_units, 0) AS incremental_units
FROM promo_units pu
JOIN Product pr ON pu.sku = pr.sku
LEFT JOIN non_promo_units np ON pu.sku = np.sku
ORDER BY incremental_units DESC
LIMIT 5;

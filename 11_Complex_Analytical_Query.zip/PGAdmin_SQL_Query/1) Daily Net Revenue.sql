-- Daily net revenue per store and day
-- Edit the VALUES(...) in params to test different ranges or a specific store.
WITH params AS (
  --            start_date    end_date      store_id (NULL = all stores)
  VALUES ('2023-07-01'::date,'2023-07-31'::date, NULL::int)
),
sales AS (
  SELECT
      s.store_id,
      DATE(s.sale_datetime) AS sale_date,
      SUM(si.quantity_sold * si.unit_price)                                   AS gross_revenue,
      SUM(si.quantity_sold * COALESCE(si.promo_discount, 0))                  AS promo_discount_total,
      SUM(si.quantity_sold * (si.unit_price - COALESCE(si.promo_discount,0))) AS net_revenue
  FROM Sale s
  JOIN SaleItem si USING (sale_id)
  JOIN params p ON TRUE
  WHERE DATE(s.sale_datetime) BETWEEN p.column1 AND p.column2
    AND (p.column3 IS NULL OR s.store_id = p.column3)
  GROUP BY s.store_id, DATE(s.sale_datetime)
),
returns AS (
  SELECT
      s.store_id,
      DATE(s.sale_datetime) AS sale_date,
      SUM(pr.quantity_returned * (si.unit_price - COALESCE(si.promo_discount,0))) AS refund_amount
  FROM ProductReturn pr
  JOIN Sale       s  ON s.sale_id = pr.sale_id
  JOIN SaleItem   si ON si.sale_id = pr.sale_id AND si.sku = pr.sku
  JOIN params p  ON TRUE
  WHERE DATE(s.sale_datetime) BETWEEN p.column1 AND p.column2
    AND (p.column3 IS NULL OR s.store_id = p.column3)
  GROUP BY s.store_id, DATE(s.sale_datetime)
),
final AS (
  SELECT
      sa.store_id,
      sa.sale_date,
      sa.gross_revenue,
      sa.promo_discount_total,
      COALESCE(r.refund_amount, 0) AS refund_amount,
      (sa.net_revenue - COALESCE(r.refund_amount, 0)) AS net_after_returns
  FROM sales sa
  LEFT JOIN returns r
    ON r.store_id = sa.store_id
   AND r.sale_date = sa.sale_date
)
-- === Show result table ===
SELECT *
FROM final
ORDER BY store_id, sale_date;

-- Units/day: Promo vs Non-Promo — Testable version

WITH params AS (
  SELECT
    DATE '2023-07-01' AS start_date,
    DATE '2023-12-01' AS end_date,
    NULL::int        AS store_id,       -- set e.g. 1 to filter, or keep NULL for all stores
    3::int           AS min_days_each   -- require at least N promo and N non-promo days
),
sales AS (
  SELECT
      s.store_id,
      si.sku,
      s.sale_datetime::date AS sale_date,
      si.quantity_sold,
      si.promo_applied
  FROM Sale s
  JOIN SaleItem si USING (sale_id)
  WHERE s.sale_datetime::date
        BETWEEN (SELECT start_date FROM params) AND (SELECT end_date FROM params)
    AND ( (SELECT store_id FROM params) IS NULL
          OR s.store_id = (SELECT store_id FROM params) )
),
bucketed AS (
  SELECT
      store_id,
      sku,
      -- numerator: total units
      SUM(CASE WHEN promo_applied THEN quantity_sold ELSE 0 END)::numeric AS promo_units,
      SUM(CASE WHEN NOT promo_applied THEN quantity_sold ELSE 0 END)::numeric AS nonpromo_units,
      -- denominators: distinct sale days (for this store × sku)
      COUNT(DISTINCT CASE WHEN promo_applied     THEN sale_date END) AS promo_days,
      COUNT(DISTINCT CASE WHEN NOT promo_applied THEN sale_date END) AS nonpromo_days
  FROM sales
  GROUP BY store_id, sku
),
calc AS (
  SELECT
      b.store_id,
      b.sku,
      -- units/day metrics
      CASE WHEN b.promo_days    > 0 THEN b.promo_units    / b.promo_days::numeric    END AS units_per_day_promo,
      CASE WHEN b.nonpromo_days > 0 THEN b.nonpromo_units / b.nonpromo_days::numeric END AS units_per_day_nonpromo,
      b.promo_days,
      b.nonpromo_days
  FROM bucketed b
),
enriched AS (
  SELECT
      c.store_id,
      c.sku,
      p.product_name,
      COALESCE(cat.category_name, 'Uncategorized') AS category_name,
      ROUND(c.units_per_day_promo, 3)    AS units_per_day_promo,
      ROUND(c.units_per_day_nonpromo, 3) AS units_per_day_nonpromo,
      c.promo_days,
      c.nonpromo_days
  FROM calc c
  JOIN Product p        ON p.sku = c.sku
  LEFT JOIN Category cat ON cat.category_id = p.category_id
)
SELECT *
FROM enriched
WHERE LEAST(promo_days, nonpromo_days) >= (SELECT min_days_each FROM params)
ORDER BY store_id, category_name, product_name, sku;

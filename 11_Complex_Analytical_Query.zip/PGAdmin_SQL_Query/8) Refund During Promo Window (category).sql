-- Refunds During Promo Window (by Category) 
-- Replace the dates (and store filter) as needed.

WITH returns_promo AS (
  SELECT
      s.store_id,
      pcat.category_name,
      SUM(pr.quantity_returned) AS units_returned,
      SUM(pr.quantity_returned * (si.unit_price - COALESCE(si.promo_discount, 0))) AS refund_amount
  FROM ProductReturn pr
  JOIN Sale       s  ON s.sale_id = pr.sale_id
  JOIN SaleItem   si ON si.sale_id = pr.sale_id AND si.sku = pr.sku
  JOIN Product    p  ON p.sku = pr.sku
  LEFT JOIN Category pcat ON pcat.category_id = p.category_id
  WHERE si.promo_id IS NOT NULL
    AND s.sale_datetime::date BETWEEN DATE '2024-01-01' AND DATE '2024-01-31' -- ← change me
    -- AND s.store_id = 1  -- ← optional filter
  GROUP BY s.store_id, pcat.category_name
)
SELECT
  store_id,
  category_name,
  units_returned,
  refund_amount
FROM returns_promo
ORDER BY refund_amount DESC, units_returned DESC;

-- Average Basket Size = items per order, per store × day
-- Edit the VALUES(...) to set your test window or a specific store (NULL = all stores).
WITH params AS (
  --            start_date    end_date      store_id
  VALUES ('2023-07-01'::date,'2023-09-30'::date, NULL::int)
),
daily AS (
  SELECT
      s.store_id,
      DATE(s.sale_datetime) AS sale_date,
      COUNT(DISTINCT s.sale_id) AS orders,
      SUM(si.quantity_sold)     AS items_sold
  FROM Sale s
  JOIN SaleItem si USING (sale_id)
  JOIN params pz ON TRUE
  WHERE DATE(s.sale_datetime) BETWEEN pz.column1 AND pz.column2
    AND (pz.column3 IS NULL OR s.store_id = pz.column3)
  GROUP BY s.store_id, DATE(s.sale_datetime)
)
-- === Result table ===
SELECT
  store_id,
  sale_date,
  orders,
  items_sold,
  ROUND(items_sold::numeric / NULLIF(orders,0), 2) AS avg_basket_size
FROM daily
ORDER BY store_id, sale_date;

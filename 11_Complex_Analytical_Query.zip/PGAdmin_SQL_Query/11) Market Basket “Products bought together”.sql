-- Market Basket: “Products bought together” (support, confidence, lift)
-- Anchored to the most recent 60 days in your Sale table

WITH anchor AS (
  SELECT COALESCE(MAX(sale_datetime)::date, CURRENT_DATE) AS last_day FROM Sale
),
recent_sales AS (
  SELECT s.sale_id, s.store_id, s.sale_datetime::date AS sdate
  FROM Sale s, anchor a
  WHERE s.sale_datetime::date BETWEEN a.last_day - INTERVAL '60 days' AND a.last_day
),
items AS (
  SELECT rs.store_id, rs.sale_id, p.department_id, d.department_name, si.sku
  FROM recent_sales rs
  JOIN SaleItem si USING (sale_id)
  JOIN Product  p  USING (sku)
  LEFT JOIN Department d ON d.department_id = p.department_id
),
dept_txn AS (
  SELECT DISTINCT store_id, department_id, department_name, sale_id FROM items
),
dept_txn_counts AS (
  SELECT store_id, department_id, department_name, COUNT(*)::numeric AS total_txns_in_dept
  FROM dept_txn GROUP BY store_id, department_id, department_name
),
prod_txn_counts AS (
  SELECT i.store_id, i.department_id, i.department_name, i.sku,
         COUNT(DISTINCT i.sale_id)::numeric AS sku_txns
  FROM items i
  GROUP BY i.store_id, i.department_id, i.department_name, i.sku
),
pairs AS (
  SELECT
    a.store_id, a.department_id, a.department_name,
    LEAST(a.sku, b.sku)    AS sku_a,
    GREATEST(a.sku, b.sku) AS sku_b,
    COUNT(DISTINCT a.sale_id)::numeric AS pair_txns
  FROM items a
  JOIN items b
    ON a.store_id      = b.store_id
   AND a.department_id = b.department_id
   AND a.sale_id       = b.sale_id
   AND a.sku           < b.sku
  GROUP BY a.store_id, a.department_id, a.department_name,
           LEAST(a.sku, b.sku), GREATEST(a.sku, b.sku)
),
metrics AS (
  SELECT
    p.store_id, p.department_id, p.department_name, p.sku_a, p.sku_b, p.pair_txns,
    dt.total_txns_in_dept, ca.sku_txns AS sku_a_txns, cb.sku_txns AS sku_b_txns,
    ROUND((p.pair_txns / NULLIF(dt.total_txns_in_dept,0))::numeric, 4) AS support,
    ROUND((p.pair_txns / NULLIF(ca.sku_txns,0))::numeric, 4) AS confidence_a_to_b,
    ROUND((p.pair_txns / NULLIF(cb.sku_txns,0))::numeric, 4) AS confidence_b_to_a,
    ROUND(((p.pair_txns * NULLIF(dt.total_txns_in_dept,0)) / NULLIF(ca.sku_txns * cb.sku_txns,0))::numeric, 4) AS lift
  FROM pairs p
  JOIN dept_txn_counts dt USING (store_id, department_id)
  JOIN prod_txn_counts ca ON ca.store_id = p.store_id AND ca.department_id = p.department_id AND ca.sku = p.sku_a
  JOIN prod_txn_counts cb ON cb.store_id = p.store_id AND cb.department_id = p.department_id AND cb.sku = p.sku_b
),
labeled AS (
  SELECT m.store_id, m.department_name, m.sku_a, pa.product_name AS product_a_name, pa.brand AS product_a_brand,
         m.sku_b, pb.product_name AS product_b_name, pb.brand AS product_b_brand,
         m.pair_txns, m.total_txns_in_dept, m.support, m.confidence_a_to_b, m.confidence_b_to_a, m.lift
  FROM metrics m
  JOIN Product pa ON pa.sku = m.sku_a
  JOIN Product pb ON pb.sku = m.sku_b
)
SELECT *
FROM (
  SELECT
    l.*,
    RANK() OVER (PARTITION BY l.store_id, l.department_name
                 ORDER BY l.lift DESC NULLS LAST, l.support DESC) AS rnk
  FROM labeled l
) r
WHERE r.rnk <= 10
ORDER BY store_id, department_name, lift DESC, support DESC;

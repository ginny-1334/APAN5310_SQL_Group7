-- Top Return Reasons by $ Value 

WITH return_values AS (
    SELECT
        rr.description AS return_reason,
        SUM(pr.quantity_returned * si.unit_price) AS total_return_value
    FROM ProductReturn pr
    JOIN ReturnReason rr 
        ON pr.reason_code = rr.reason_code
    JOIN SaleItem si 
        ON pr.sale_id = si.sale_id
        AND pr.sku = si.sku
    WHERE pr.return_date BETWEEN DATE '2024-01-01' AND DATE '2024-01-31' -- change date range
    GROUP BY rr.description
)
SELECT
    return_reason,
    total_return_value
FROM return_values
ORDER BY total_return_value DESC
LIMIT 5; -- top 5 reasons

-- Inventory Watchlist (Understock / Overstock)

SELECT
    i.store_id,
    s.address AS store_address,
    i.sku,
    p.product_name,
    i.quantity_on_hand,
    i.reorder_threshold,
    CASE
        WHEN i.quantity_on_hand < i.reorder_threshold THEN 'Understock'
        WHEN i.quantity_on_hand > i.reorder_threshold * 2 THEN 'Overstock'
        ELSE 'Normal'
    END AS stock_status
FROM Inventory i
JOIN Store s  ON i.store_id = s.store_id
JOIN Product p ON i.sku = p.sku
WHERE i.quantity_on_hand < i.reorder_threshold
   OR i.quantity_on_hand > i.reorder_threshold * 2
ORDER BY stock_status, store_id, product_name;


-- Top Categories per Month (ranked, contribution %)

WITH sales_m AS (
  SELECT
      s.store_id,
      date_trunc('month', s.sale_datetime)::date AS month_start,
      COALESCE(c.category_name, 'Uncategorized') AS category_name,
      SUM(si.quantity_sold * si.unit_price)                                   AS gross_revenue,
      SUM(si.quantity_sold * COALESCE(si.promo_discount,0))                   AS promo_discount_total,
      SUM(si.quantity_sold * (si.unit_price - COALESCE(si.promo_discount,0))) AS net_revenue
  FROM Sale s
  JOIN SaleItem si USING (sale_id)
  JOIN Product p   USING (sku)
  LEFT JOIN Category c ON c.category_id = p.category_id
  WHERE DATE(s.sale_datetime) BETWEEN {{start_date}} AND {{end_date}}
  [[ AND {{store_id}} ]]
  GROUP BY s.store_id, date_trunc('month', s.sale_datetime), COALESCE(c.category_name, 'Uncategorized')
),
returns_m AS (
  SELECT
      s.store_id,
      date_trunc('month', s.sale_datetime)::date AS month_start,
      COALESCE(c.category_name, 'Uncategorized') AS category_name,
      SUM(pr.quantity_returned * (si.unit_price - COALESCE(si.promo_discount,0))) AS refund_amount
  FROM ProductReturn pr
  JOIN Sale       s  ON s.sale_id = pr.sale_id
  JOIN SaleItem   si ON si.sale_id = pr.sale_id AND si.sku = pr.sku
  JOIN Product    p  ON p.sku = pr.sku
  LEFT JOIN Category c ON c.category_id = p.category_id
  WHERE DATE(s.sale_datetime) BETWEEN {{start_date}} AND {{end_date}}
  [[ AND {{store_id}} ]]
  GROUP BY s.store_id, date_trunc('month', s.sale_datetime), COALESCE(c.category_name, 'Uncategorized')
),
combined AS (
  SELECT s.store_id, s.month_start, s.category_name,
         (s.net_revenue - COALESCE(r.refund_amount, 0)) AS net_after_returns
  FROM sales_m s
  LEFT JOIN returns_m r USING (store_id, month_start, category_name)
),
store_month_totals AS (
  SELECT store_id, month_start, SUM(net_after_returns) AS month_total_net
  FROM combined GROUP BY store_id, month_start
),
ranked AS (
  SELECT
    c.store_id, c.month_start, c.category_name, c.net_after_returns,
    RANK() OVER (PARTITION BY c.store_id, c.month_start ORDER BY c.net_after_returns DESC) AS category_rank,
    ROUND(c.net_after_returns::numeric / NULLIF(t.month_total_net, 0), 4) AS contribution_pct
  FROM combined c
  JOIN store_month_totals t USING (store_id, month_start)
)
SELECT store_id, month_start, category_rank, category_name, net_after_returns, contribution_pct
FROM ranked
WHERE category_rank <= 5
ORDER BY store_id, month_start DESC, category_rank, category_name;

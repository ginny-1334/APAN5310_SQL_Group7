--  Scheduled Labor Hours (headcount & hours)

SELECT
  e.store_id,
  ss.shift_date,
  ROUND(
    SUM(
      GREATEST(
        EXTRACT(EPOCH FROM (
          CASE
            WHEN ss.end_time >= ss.start_time
              THEN ss.end_time - ss.start_time
            ELSE ss.end_time - ss.start_time + INTERVAL '24 hours'
          END
        )) / 3600.0,
        0
      )
    )::numeric,
    2
  ) AS scheduled_hours,
  COUNT(DISTINCT ss.employee_id) AS scheduled_headcount
FROM ShiftSchedule ss
JOIN Employee e ON e.employee_id = ss.employee_id
WHERE ss.shift_date BETWEEN {{start_date}} AND {{end_date}}
  [[AND e.store_id = {{store_id}}]]
GROUP BY e.store_id, ss.shift_date
ORDER BY ss.shift_date, e.store_id;

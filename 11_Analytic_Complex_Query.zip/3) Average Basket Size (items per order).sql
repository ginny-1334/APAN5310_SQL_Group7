-- Average Basket Size (items per order)

WITH daily AS (
  SELECT
      s.store_id,
      DATE(s.sale_datetime) AS sale_date,
      COUNT(DISTINCT s.sale_id) AS orders,
      SUM(si.quantity_sold)     AS items_sold
  FROM Sale s
  JOIN SaleItem si USING (sale_id)
  WHERE DATE(s.sale_datetime) BETWEEN {{start_date}} AND {{end_date}}
  [[ AND {{store_id}} ]]
  GROUP BY s.store_id, DATE(s.sale_datetime)
)
SELECT
  store_id, sale_date, orders, items_sold,
  ROUND(items_sold::numeric / NULLIF(orders,0), 2) AS avg_basket_size
FROM daily
ORDER BY store_id, sale_date;

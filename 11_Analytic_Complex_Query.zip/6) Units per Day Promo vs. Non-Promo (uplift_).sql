-- Units/Day: Promo vs. Non-Promo (uplift%)

WITH sales_window AS (
  SELECT
      s.store_id,
      si.sku,
      s.sale_datetime::date AS sale_date,
      si.quantity_sold,
      si.promo_applied
  FROM Sale s
  JOIN SaleItem si USING (sale_id)
  JOIN Product p  USING (sku)
  WHERE DATE(s.sale_datetime)
        BETWEEN COALESCE({{start_date}}, CURRENT_DATE - INTERVAL '60 days')
            AND COALESCE({{end_date}},   CURRENT_DATE)
    [[AND s.store_id = {{store_id}}]]
    [[AND p.category_id = {{category_id}}]]
),
bucketed AS (
  SELECT
      store_id, sku,
      SUM(CASE WHEN promo_applied THEN quantity_sold ELSE 0 END)::numeric AS promo_units,
      COUNT(DISTINCT CASE WHEN promo_applied     THEN sale_date END)      AS promo_days,
      SUM(CASE WHEN NOT promo_applied THEN quantity_sold ELSE 0 END)::numeric AS nonpromo_units,
      COUNT(DISTINCT CASE WHEN NOT promo_applied THEN sale_date END)          AS nonpromo_days
  FROM sales_window
  GROUP BY store_id, sku
),
rates AS (
  SELECT
      b.store_id, b.sku,
      CASE WHEN b.promo_days    > 0 THEN b.promo_units    / b.promo_days::numeric    END AS units_per_day_promo,
      CASE WHEN b.nonpromo_days > 0 THEN b.nonpromo_units / b.nonpromo_days::numeric END AS units_per_day_nonpromo,
      CASE
        WHEN b.nonpromo_days > 0 AND b.nonpromo_units > 0
        THEN (
               (b.promo_units    / NULLIF(b.promo_days,0)::numeric)
             - (b.nonpromo_units / NULLIF(b.nonpromo_days,0)::numeric)
             )
             / (b.nonpromo_units / b.nonpromo_days::numeric)
      END AS uplift_pct,
      b.promo_days, b.nonpromo_days
  FROM bucketed b
)
SELECT
  r.store_id, r.sku, p.product_name,
  COALESCE(c.category_name, 'Uncategorized') AS category_name,
  ROUND(r.units_per_day_promo,     3) AS units_per_day_promo,
  ROUND(r.units_per_day_nonpromo,  3) AS units_per_day_nonpromo,
  ROUND(r.uplift_pct,              3) AS uplift_pct,
  r.promo_days, r.nonpromo_days
FROM rates r
JOIN Product p  USING (sku)
LEFT JOIN Category c ON c.category_id = p.category_id
WHERE r.promo_days    >= COALESCE({{min_days_each}}, 3)
  AND r.nonpromo_days >= COALESCE({{min_days_each}}, 3)
ORDER BY uplift_pct DESC NULLS LAST, units_per_day_promo DESC NULLS LAST
LIMIT COALESCE({{top_n}}, 10);

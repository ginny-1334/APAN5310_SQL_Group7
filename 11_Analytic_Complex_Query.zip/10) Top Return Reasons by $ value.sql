-- Top Return Reasons by $ value

WITH return_values AS (
    SELECT
        rr.description AS return_reason,
        SUM(pr.quantity_returned * si.unit_price) AS total_return_value
    FROM ProductReturn pr
    JOIN ReturnReason rr ON pr.reason_code = rr.reason_code
    JOIN SaleItem si ON pr.sale_id = si.sale_id AND pr.sku = si.sku
    WHERE pr.return_date BETWEEN CAST({{start_date}} AS date) AND CAST({{end_date}} AS date)
    [[AND rr.description = {{return_reason}} ]]
    GROUP BY rr.description
)
SELECT return_reason, total_return_value
FROM return_values
ORDER BY total_return_value DESC
LIMIT 5;
